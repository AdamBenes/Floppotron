# Moppy2
The evolution of the Musical flOPPY controller.

Everything* you need to make your own musical floppy drives!

The [wiki](https://github.com/SammyIAm/Moppy2/wiki) has additional information, instructions for getting started, and some other helpful info.  If you can't find what you're looking for and have a [question](https://github.com/SammyIAm/Moppy2/issues/new?labels=question) or run into trouble and [need help](https://github.com/SammyIAm/Moppy2/issues/new?body=If%20you%27re%20having%20trouble%2C%20try%20to%20describe%20what%20you%27ve%20done%20so%20far%20and%20what%20%2Adoes%2A%20work%20so%20we%20don%27t%20ask%20you%20to%20try%20things%20you%27ve%20already%20done.%20%20If%20you%20can%20provide%20screenshots%2C%20logs%2C%20or%20videos%2C%20they%20can%20really%20help%20get%20a%20faster%20response%21) just use those links to create a new issue.

Have fun!

\* Okay, not _everything_; you'll need to provide all the hardware.

-------
*If you've been here before but you're confused by all the newness, the original [MoppyClassic](https://github.com/SammyIAm/MoppyClassic) has still been preserved for posterity, but will no longer receive any updates.*
