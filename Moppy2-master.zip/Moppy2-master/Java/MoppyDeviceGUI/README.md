# MoppyControlGUI
Java GUI that acts as a Moppy Device for testing purposes.
